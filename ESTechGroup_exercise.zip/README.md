# ESTechGroup
Simple display product price

## Instructions
Open terminal and run "cd backend"
Then, run "composer install"
In .env set all MySQL connection settings
After, run in terminal "php artisan migrate"
Finally run "php artisan serve"

Open in any browser localhost:8000 (or any other port set by php serve)